#!/usr/bin/env ipython
# -*- coding: utf-8 -*-
"""

@author: Marcos Bermejo
"""


import os #Módulo encargado de ver si existen o no directorios
import re #Módulo para búsequeda de patrones en secuencia
import sys #Módulo encargado de proveer variables y funcionalidades
import shutil #Módulo encargado de mover y comprobar presencia de archivos

from Bio import Seq
from Bio import SeqIO #Módulo para trabajar con secuencias de aminoácidos
from Bio.ExPASy import Prosite,Prodoc #Módulo de acceso a bases de datos biológicas
from subprocess import Popen, PIPE #Módulo para creación de subprocesos

import Blaster
import Find_domains
import Maketree

ayuda=input("""\nSi no quiere visualizar la ayuda introduzca 'no'. Si quiere 
salir del programa introduzzca 'exit'. Si introduce cualquier otra cosa se le 
mostrará la ayuda y posteriormente se ejecutará el programa\n""")

if ayuda == "no":
    pass
elif ayuda == "exit": #opcion de salida del programa
    #mensaje de despedida
    print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
    sys.exit()

else:
    print("""\n            ---------------BIENVENIDO AL PROGRAMA---------------
      
  Esta es la ayuda para el programa realizado como trabajo final de la
  asignatura programación para bioinformática de cuarto de biotecnología. La
  funcionalidad del programa se puede resumir en 3 puntos:
          
      -En primer lugar, a partir de un genebank introducido como un archivo en 
       formato.gbff y un archivo con querys en formato .fasta se realiza un 
       blast. Sobre el resultado de dicho blast se filtrarán los hits en 
       función de valores introducidos por el usuario para coverage, identity y
       evalue. Los resultados filtrados y no filtrados se almacenarán en la
       carpeta 'Blast_results'. Se generará de forma paralela un archivo para
       cada query con los subjects para los que se han obtenido hits tras el
       filtrado junto con las secuencias de dichos subjects
           
      -En segundo lugar, a partir de cada archivo de una query y sus subjects 
       se realizará un alineamiento de secuencias mediante MUSCLE. Una vez
       obtenidos los alineamientos se generará un árbolfilogenético para cada
       query. Si una query solo tiene hit con un subject no se podrá generar
       árbol. Los resultados serán almacenados en arcivos .tree que se
       encontrarán dentro de la carpeta 'Trees'.
           
      -Por último, se parseará un archivo con el nombre 'prosite.dat' que 
       contendrá datos de patrones de proteínas de prosite. Una vez creado el
       archivo 'prosite_parsed.tsv' se buscarán los patrones en las secuencias
       de los subjects obtenidas en el primer paso. De cada patrón con 
       coincidencia se almacenará el nombre, la descripción, la accesión y el
       propio patrón en archivos llamados query_patterns.txt. Dichos archivos
       se encontrarán dentro de la carpeta 'Patterns_found'
           
  Los resultados de las distintas ejecuciones se irán guardando en una carpeta
  llamada Results_ y un número. Si se superan las 1000 ejecuciones sin borrar
  ninguna carpeta de resultadoslos resultados dejarán de almacenarse.
           
              ------------DISFRUTE DEL PROGRAMA--------------
  """)

#Se guarda el path donde nos encotramos y en base a el se crea la carpeta Results junto con un número que indique el proyecto actual
path=os.getcwd()
for i in range(1,1000):
    if os.path.isdir(path+"/Results_"+str(i))==False:
        os.mkdir("Results_"+str(i))
        break

print("\n---Los resultados de este proyecto se van a almacenar en la carpeta 'Results_"+str(i)+"'---")

#Se crea la carpeta 'Blast_results' para los resultados del Blastp y se mete dicha carpeta dentro de la carpeta Results
os.mkdir("Blast_results")
shutil.move("Blast_results","Results_"+str(i))

#Se crea la carpeta 'Trees' para los resultados de los árboles y se mete dicha carpeta dentro de la carpeta Results
os.mkdir("Trees")
shutil.move("Trees","Results_"+str(i))

#Se pregunta por el archivo que se desea usar como genebank y se ejecuta el parseo de dicho archivo
genebank=input("\nPor favor, introduzca que genebank deseas seleccionar para que sea el subject del blast\n")
Blaster.Parser(genebank)

#Se pregunta por el archivo que se quiere usar como query para el blast y se ejecuta el Blastp con los datos introducidos
query=input("Por favor, introduzca que archivo en formato fasta desea que sea la query del blast\n")
Blaster.BlastP(query)

#Se pregunta al usuario por un valor de coverage y se repite la funvión hasta que coverage tenga un valor adecuado
coverage=None
while coverage == None:
    coverage=Blaster.ask_coverage()

#Se pregunta al usuario por un valor de identidad y se repite la funvión hasta que coverage tenga un valor adecuado
identity=None
while identity == None:
    identity=Blaster.ask_identity()

#Se pregunta al usuario por un valor de evalue y se repite la funvión hasta que coverage tenga un valor adecuado
evalue=None
while evalue == None:
    evalue=Blaster.ask_evalue()

#Se filtran los valores del blast obtenidos aplicando los valores introducidos por el usuario
#La función devuelve la lista con los nombres de las querys que superan el filtro y esta lista se almacena en lista_querys
lista_querys=Blaster.Filtrar(coverage ,identity ,evalue)

#se mueve el resultadod el blast entero y filtrado a la carpeta correspondiente
shutil.move("blast_result.tsv","Results_"+str(i)+"/Blast_results")
shutil.move("blast_result_filtered.tsv","Results_"+str(i)+"/Blast_results")
print("\n---El resultado del blast filtrado según los parámetros indicados se ecnuentra en el archivo llamado 'blast_result_filtered' dentro de la carpeta 'Blast_results'---\n")

#Se ejecuta el alineamiento de secuencias y después la realización de los árboles con dichos alineamientos
Maketree.Alinear(lista_querys)
Maketree.Hacer_arbol(lista_querys,i)

#Para cada query se mueve su árbol a la carpeta de árboles. Si para una query no hay un árbol hecho es porque esa query solo tiene hit con un subject y se le indica al usuario
for a in lista_querys:

    process = Popen(['mv',a+'.tree',"Results_"+str(i)+"/Trees"], stderr=PIPE)
    error_found = process.stderr.read().decode("utf-8")    
    process.stderr.close()
    if not error_found:
        pass
    else:
        print("\n---El arbol para la query "+a+" no ha podido ser creado porque esta query solo ha obtenido hit con una secuencia---")

print("\n---Los árboles filogenéticos han sido realizados con éxito, se ecnuentran en los archivos query.tree dentro de la carpeta 'Trees'---")

#Se intenta parsear el archivo 'prosite.dat' y si se consigue se buscan los patrones que haya en las secuencias de los subjects de cada archivo de querys
Find_domains.Parseo_prosite()

if os.path.isfile(path+"/prosite_parsed.tsv"):
    Find_domains.Buscar_dominios(lista_querys)
    #Se crea la carpeta 'Patterns_found' para los resultados de la búsqueda de patrones y se mete dicha carpeta dentro de la carpeta Results
    os.mkdir("Patterns_found")
    shutil.move("Patterns_found","Results_"+str(i))
    for b in lista_querys:
        shutil.move(b+"_patterns.txt","Results_"+str(i)+"/Patterns_found") #se trasladan los archivos con la coincidencia de patrones a la carpeta 'Patterns_found'

for c in lista_querys:
    os.remove(c+".fasta") #se borran los archivos con los subjects y sus secuencias
    os.remove(c+"_alineado.fasta") #se borran los archivos que contienen los alineamientos para realizar el árbol

#mensaje de despedida
print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")






