#!/usr/bin/env ipython
# -*- coding: utf-8 -*-
"""

@author: Marcos Bermejo
"""

import os #Módulo encargado de ver si existen o no directorios
import re #Módulo para búsequeda de patrones en secuencia
import sys #Módulo encargado de proveer variables y funcionalidades

from Bio.ExPASy import Prosite,Prodoc #Módulo de acceso a bases de datos biológicas

#función que realiza el parseo del archivo prosite.dat para obtener los patrones de proteínas
def Parseo_prosite():
    try:
        ruta=os.getcwd()
        if os.path.isfile(ruta+"/prosite_parsed.tsv"): #si el archivo parseado ya existe se sale de la función para ahorrar computación
            return
        
        else:
            handle = open("prosite.dat","r") #se abre el archivo a parsear
            resultado = open("prosite_parsed.tsv","w") #se crea el archivo donde se almacenará el resultado
            resultado.write("name"+"\t"+"accession"+"\t"+"description"+"\t"+"pattern"+"\n")
            records = Prosite.parse(handle)
            for record in records: #se realiza el parsea almacenando para cada patrón su nombre, accesión, descripción y el propio patrón
                nombre=record.name
                accesion=record.accession
                descripcion=record.description
                patron=record.pattern
                result=str(nombre+"\t"+accesion+"\t"+descripcion+"\t"+patron+"\n")
                resultado.write(result) #se escriben los datos de cada patrón en el archivo de resultado
            records.close()
            resultado.close()
    except: #si no se encuentra el archivo prosite.dat en la carpeta se pide que se obtenga
        print("\n---No se ha podido encontrar el archivo 'prosite.dat' en la carpeta donde se encuentra el programa.\nPor favor, mueva el archivo a esta carpeta o renombre el archivo para que coincida con el nombre indicado.---")
        print("\n---Se continuará la ejecución del programa pero no se realizará la búsqueda de patrones---")

#función para buscar patrones de prosite en las secuencias de los subjects para cada query        
def Buscar_dominios(querys,patrones="prosite_parsed.tsv"):
    for query in querys:
        
        sub=open(query+".fasta","r") #se abre el archivo con los subjects y sus secuencias
        sub=sub.read()
        a=sub.split("\n") #se separa el archivo por los saltos de linea 
    
        patron=open(patrones,"r") #se abre el archivo de prosite con los patrones
        patron=patron.read()
        b=patron.split("\n") #se separa el archivo por los saltos de linea (cada linea contiene un patrón)
    
        archivo_final=open(query+"_patterns.txt","w") #se crea el archivo que contendrá los patrones
        
        for i in range(len(a)//2): #se recorre el archivo con las secuancias de los subjects de dos en dos lineas
            sec=a[2*i+1] #secuancias
            nom=a[2*i] #ID de los subjects
            secuencia=str("Patterns in sequence "+nom[1:]+":\n\n")
            archivo_final.write(secuencia)
            for j in b[1:]: #se recorre el archivo con los patrones sin tener en cuenta la cabecera
                if j=='': #si es una linea en blanco del archivo no se hace búsqueda
                    pass
                else:
                    j=j.split("\t") #se separa cada linea del archivo con los patrones en funcion de tabulador
                    patron_re=conversionpro_re(j[3]) #se convierte el patrón (j[3]) a lenguaje de re
                    if j[3] != "": #en el parseo de prosite se escriben patrones de los cuales hay nombre por ejemplo pero no patrón en si. Con estos patrones no se realiza búsqueda
                        if re.search (patron_re,sec): #si se encuentra el patrón en la secuencia
                            escribir=str("\tName: "+j[0]+"\n\tAccession: "+j[1]+"\n\tDescription: "+j[2]+"\n\tPattern: "+j[3])
                            archivo_final.write(escribir) #se escriben los datos del patrón en el archivo
                            veces=0
                            coord=[]
                            for coincidencias in re.finditer(patron_re,sec): #se buscan todos los sitios de la secuencia en los que aparece el patrón
                                #se almacenan para cada patrón los aas de inicio y final en los que aparece en la secuencia y el número de veces que aparece
                                inicio=coincidencias.start()
                                fin=coincidencias.end()
                                coord.append([inicio,fin])
                                veces=veces+1
                            
                            num_veces=str("\n\tTimes found: "+str(veces)+"\n\tPositions in sequence: "+str(coord)+"\n\n")
                            archivo_final.write(num_veces) #se escriben en el archivo las coordenadas y las veces que aparece cada patrón
        
        
        archivo_final.close
    print("\n---La localización de patrones en las secuencias se ha llevado a cabo con éxito, se han almacenado en los archivos query_patterns dentro de la carpeta 'Patterns_found'---")    

#función que realiza los cambios necesarios para que los patrones escritos en lenguaje de prosite sean entendidos por el módulo re       
def conversionpro_re(prosite):
    
    #lista con los cambios  a realizar. Se cambian unos elementos de la string por otros mediante la función replace
    patronfinal=prosite.replace(".","")
    patronfinal=patronfinal.replace("x",".")
    patronfinal=patronfinal.replace("-","")
    patronfinal=patronfinal.replace("{","[^")
    patronfinal=patronfinal.replace("}","]")
    patronfinal=patronfinal.replace("(","{")
    patronfinal=patronfinal.replace(")","}")
    patronfinal=patronfinal.replace("<","^")
    patronfinal=patronfinal.replace(">","$")
    return(patronfinal) #devuelve el patrón entendible por re