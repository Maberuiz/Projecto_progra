#!/usr/bin/env ipython
# -*- coding: utf-8 -*-
"""

@author: Marcos Bermejo
"""

import os  #Módulo encargado de ver si existen o no directorios
import sys #Módulo encargado de proveer variables y funcionalidades

from Bio import Seq
from Bio import SeqIO #Módulo para trabajar con secuencias de aminoácidos
from subprocess import Popen, PIPE  #Módulo para creación de subprocesos

def Parser(bank): #Función para parsear el archivo genebank que se introduzca. Bank es el nombre del genebank introducido por el usuario

    if bank[-5:] != ".gbff": #si el archivo no tiene la extensión .gbff se pide la introducción de uno
        no_archivo=str(input("\nEl archivo introducido no tiene la extensión adecuada, por favor, introduzca el nombre del archivo en formato gene bank de la manera archivo.gbff\nSi por el contrario quiere salir del programa escriba 'exit'\n"))
        
        if no_archivo == "exit": #opcion de salida del programa
            #mensaje de despedida
            print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
            sys.exit()
        
        else:
            Parser(no_archivo) #se vuelve a ejecutar la función con el nuevo archivo introducido
    
    else:
        subject=open("subject","w") #se crea el archivo que contendrá el resultado parseado
        
        if os.path.isfile("subject.fasta") == True:  #si ya existe el archivo subject.fasta se borra
            os.remove("subject.fasta")
        else:
            pass
        
        try:  #se intenta parsear el archivo pero si no esta en el formato adecuado nos iremos al except  
            with open(bank, "r") as input_handle:
                
                for record in SeqIO.parse(input_handle, "genbank"):
                    print()
                    
                    for feature in record.features:
                        if feature.type == 'CDS':
                            
                            #como estraer la posicion del ADN (tener cuidado con la cadena)
                            try:
                                locus = feature.qualifiers['locus_tag'][0] #coges el ID de la secuencia
                                secuencia_proteina= feature.qualifiers['translation'][0] #coges la secuencia traducida
                                resultado=str(">"+locus+"\n"+ secuencia_proteina +"\n") #estructuramos lo que queremos escribir en el archivo
                                subject.write(resultado) #escribimos en el archivo
                            
                            except: #se usa este except si la translación no se puede realizar
                                pass
        
        except: #se pide la introducción de un nuevo archivo válido
            error=str(input("\nEl archivo introducido como genebank no es correcto, por favor, introduzca el nombre de un archivo .gbff correcto o escriba 'exit' para salir del programa\n"))
            
            if error == ("exit"):#opcion de salida del programa
                #mensaje de despedida
                print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
                sys.exit()
            
            else:
                Parser(error)
        
        subject.close() #cerramos el archivo

#Función para realizar el Blastp
def BlastP(archivo_query,subject="subject"): #archivo_query es introducido por el usuario y subject siempre se llamará igual porque viene del Parser
        
    if archivo_query[-6:] != ".fasta": #si el archivo no tiene la extensión .fasta se pide la introducción de uno
        mal_archivo=str(input("\nEl archivo introducido no tiene la extensión adecuada, por favor, introduzca el nombre de un archivo en formato fasta de la manera archivo.fasta\nSi por el contrario quiere salir del programa escriba 'exit'\n"))
        if mal_archivo == "exit": #opcion de salida del programa
            #mensaje de despedida
            print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
            sys.exit()
        else:
            BlastP(mal_archivo) #se vuelve a ejecutar la función con el nuevo archivo introducido
        
    else:
        #introducimos en proceso la realización del blast
        proceso = Popen(['blastp','-query',archivo_query,'-subject',subject,'-outfmt',"6 qseqid qcovs pident evalue sseqid" ], stdout=PIPE, stderr=PIPE)
        
        error_encontrado = proceso.stderr.read().decode("utf-8") #se almacenan posibles errores ocurridos durante el blast
        proceso.stderr.close()
        
        listado = proceso.stdout.read().decode("utf-8") #en listado almacenamos el resultado del blast
        proceso.stdout.close()
        
        my_output = open("blast_result.tsv","w") #abrimos el archivo que albergará los resultados del blast
        cabecera=str("query_ID\tqcovs\tpident\tevalue\tsubject_ID\n")
        my_output.write(cabecera)
        my_output.write(listado) #escribimos en el archivo el resultado del blast
        
        if not error_encontrado: #si no se ha producido error durante el blast se sigue la ejecución del programa
            print("\n---El blastp ha sido realizado con éxito, el resultado se ecnuentra en el archivo llamado 'blast_result' dentro de la carpeta 'Blast_results'---\n")
        
        else: #si se produce algun error durante el blast se pide la introducción de un archivo correcto
            print("\nSe produjo el siguiente error durante el Blast:\n%s" % error_encontrado)
            opcion=str(input("Si quiere volver a intentar el Blast, introduzca el nombre del archivo de nuevo correctamente, en caso de querer salir del programa, introduzca la palabra 'exit'\n"))
            
            if opcion == "exit": #opcion de salida del programa
                #mensaje de despedida
                print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
                sys.exit()
            
            else:
                BlastP(opcion)
        
        my_output.close()
        

def ask_coverage(): #Función para pedirle al usuario la introducción de un valor para el coverage
    try:          
        cover=float(input("\nPor favor, introduzca por debajo de que porcentaje de coverage quiere excluir los alineamientos:\n"))
        
        if cover < 0 or cover > 100: #si el valor no esta entre 0 y 100 se le pide al usuario que introduzca uno correcto
            cov_error=input("\nEl valor de coverage debe estar entre 0 y 100, si desea introducir otro valor escriba 'valor', si desea salir del programa escriba 'exit'\n")
            
            if cov_error == "exit": #opcion de salida del programa
                #mensaje de despedida
                print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
                sys.exit()
            
            elif cov_error == "valor":
                return
            
            else: #si el usuario no introduce ninguna de las dos palabras indicadas se le devuelve al inicio de la función
                print("\nNo ha introducido ninguna de las palabras indicadas por lo que se volverá a pedir la introducción de un valor para coverage")
                return
                
        else:
            return(cover)
        
    except ValueError: #se irá por ese camino si se introduce cualquier cosa que no sea un número
        error1=input("\nEl valor de coverage debe ser un NÚMERO entre 0 y 100, si desea introducir otro valor escriba 'valor', si desea salir del programa escriba 'exit'\n")
        
        if error1 == "exit": #opcion de salida del programa
            #mensaje de despedida
            print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")    
            sys.exit()
        
        elif error1 == "valor":
                return
        
        else: #si el usuario no introduce ninguna de las dos palabras indicadas se le devuelve al inicio de la función
                print("\nNo ha introducido ninguna de las palabras indicadas por lo que se volverá a pedir la introducción de un valor para coverage")
                return


def ask_identity(): #Función para pedirle al usuario la introducción de un valor para la identidad
    try:   
        iden=float(input("\nPor favor, introduzca por debajo de que porcentaje de identidad quiere excluir los alineamientos:\n"))
        
        if iden < 0 or iden > 100: #si el valor no esta entre 0 y 100 se le pide al usuario que introduzca uno correcto
            iden_error=input("\nEl valor de identidad debe estar entre 0 y 100, si desea introducir otro valor escriba 'valor', si desea salir del programa escriba 'exit'\n")
            
            if iden_error == "exit":#opcion de salida del programa
                #mensaje de despedida
                print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
                sys.exit()
            
            elif iden_error == "valor":
                return
            
            else:#si el usuario no introduce ninguna de las dos palabras indicadas se le devuelve al inicio de la función
                print("\nNo ha introducido ninguna de las palabras indicadas por lo que se volverá a pedir la introducción de un valor para identidad")
                return
                
        else:
            return(iden)
     
    except ValueError:#se irá por ese camino si se introduce cualquier cosa que no sea un número
        error2=input("\nEl valor de identidad debe ser un NÚMERO entre 0 y 100, si desea introducir otro valor escriba 'valor', si desea salir del programa escriba 'exit'\n")
        
        if error2 == "exit": #opcion de salida del programa
             #mensaje de despedida
             print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")   
             sys.exit()
        
        elif error2 == "valor":
                return
        
        else: #si el usuario no introduce ninguna de las dos palabras indicadas se le devuelve al inicio de la función
                print("\nNo ha introducido ninguna de las palabras indicadas por lo que se volverá a pedir la introducción de un valor para identidad")
                return


def ask_evalue(): #Función para pedirle al usuario la introducción de un valor para el evalue
    try:
        evalu=float(input("\nPor favor, introduzca a partir de que valor de evalue desea descartar los alineamientos:\n"))
        
        if evalu <= 0: #si el valor es menor o igual que 0 se le pide al usuario que introduzca uno correcto
            evalu_error=input("\nSi el valor de evalue es 0 o menor que 0 todos los hits se verán excluidos, por favor, escriba 'valor' para introducir un nuevo valor de evalue o escriba 'exit' para salir del programa\n")
            
            if evalu_error == "exit": #opcion de salida del programa
                #mensaje de despedida
                print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")
                sys.exit()
            
            elif evalu_error == "valor":
                return
            
            else: #si el usuario no introduce ninguna de las dos palabras indicadas se le devuelve al inicio de la función
                print("\nNo ha introducido ninguna de las palabras indicadas por lo que se volverá a pedir la introducción de un valor para evalue")
                return
        
        else:
            return(evalu)
    
    except ValueError: #se irá por ese camino si se introduce cualquier cosa que no sea un número
        error3=input("\nEl valor de evalue debe ser un NÚMERO, si desea introducir otro valor escriba 'valor', si desea salir del programa escriba 'exit'\n")
        
        if error3 == "exit": #opcion de salida del programa
            #mensaje de despedida
            print("\n------Gracias por haber usado este programa, ¡hasta pronto!------\n\n")    
            sys.exit()
        
        elif error3 == "valor":
                return
        
        else: #si el usuario no introduce ninguna de las dos palabras indicadas se le devuelve al inicio de la función
                print("\nNo ha introducido ninguna de las palabras indicadas por lo que se volverá a pedir la introducción de un valor para evalue")
                return


#función para filtrar los resultados del blast en función de los valores introducidos por el usuario          
def Filtrar(coverage,identity,evalue,blastp="blast_result.tsv"): #los valores para coverage, identity y evalue han sido introducidos por el usuario en sus respectivas funciones
    
    archivo=open(blastp) #se abre el archivo que contiene el resultado del blast
    f=archivo.read()
    Listado=list(f.split("\n")) #se separa el archivo por los cambios de linea
    
    Lista2=[]
    for q in Listado: #este bucle crea una lista de listas. En cada sublista se almacena cada uno de los valores de la columna del resultado del blast
        
        if q=='':
            pass
        
        else:
            Lista2.append(q.split('\t'))
    
    blast_filtrado=open("blast_result_filtered.tsv","w") #se crea el archivo que almacenará los resultados del blast filtrados
    cabecera=str("query_ID\tqcovs\tpident\tevalue\tsubject_ID\n")
    blast_filtrado.write(cabecera)
    Listafinal=[]
    for j in range(1,len(Lista2)): #este bucle es el propio filtro donde se compara si cada valor supera el filtro de los números introducidos
        
        if float(Lista2[j][1])>=coverage and float(Lista2[j][2])>=identity and float(Lista2[j][3])<=evalue:
            Listafinal.append(Lista2[j]) #nos quedamos con las filas del resultado del blast que superan el filtro
            add=str(Lista2[j][0]+"\t"+Lista2[j][1]+"\t"+Lista2[j][2]+"\t"+Lista2[j][3]+"\t"+Lista2[j][4]+"\n")
            blast_filtrado.write(add) #se añaden las filas filtradas al archivo de los resultados del blast filtrados
    
    blast_filtrado.close()
    querys=[]
    for k in range(len(Listafinal)): #generamos una lista que contenga (1 vez) los nombres de las querys con algun hit que ha superado el filtro
        
        if Listafinal[k][0] not in querys:
            querys.append(Listafinal[k][0])
            
    secsubjects=open('subject','r') #abrimos el archivo del genebank parseado que contiene las secuencias de los subjects
    secsubjects=secsubjects.read()
    g=secsubjects.split("\n") #separamos los elementos del archivo por salto de linea
   
    for l in querys: #para cada query
        nombre=(l+".fasta") 
        archivo=open(nombre,'w') #se genera el archivo que almacenará el ID de los subjects y sus secuencias
        
        listaprov=[]
        listasecs=[]
        
        for m in range(len(Listafinal)): #generamos una lista que contiene los ID de los subjects de los que queremos su secuencia
            
            if Listafinal[m][0]==l:
                listaprov.append(Listafinal[m][4])
        
        for n in listaprov: #recorremos la lista con los ID de los subjects
            
            for p in range(len(g)//2): #recorremos el archivo de dos en dos lineas
                
                if g[2*p] == ">" + n: #comparamos si el ID del subject es el que queremos
                    listasecs.append(g[2*p]+"\n"+g[2*p+1]) #añadimos la secuencia correspondiente
        
        archivo.write("\n".join(listasecs)) #escribimos en el archivo el ID del subject y su secuencia
        
    archivo.close()
    return(querys) #devolvemos la lista con las querys al programa principal ya que la necesitaremos más adelante









    
    
    

    
    
    
    
    