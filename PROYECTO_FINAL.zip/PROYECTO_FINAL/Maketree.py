#!/usr/bin/env ipython
# -*- coding: utf-8 -*-
"""

@author: Marcos Bermejo
"""

from subprocess import Popen, PIPE #Módulo de acceso a bases de datos biológicas

#función para realizar el alineamiento de secuencias
def Alinear(lista_querys):
    
    for i in lista_querys: #se recorren las distintas querys que tendrán su archivo con las secuencias a alinear
        proceso1 = Popen(['muscle','-in',i+".fasta"], stdout=PIPE, stderr=PIPE) #subproceso de alineamiento mediante muscle
        listado1 = proceso1.stdout.read().decode("utf-8") #en listado1 metemos el resultado del alineamiento
        proceso1.stdout.close()
        my_output1 = open(i+"_alineado.fasta","w") #abrimos el archivo que contendrá el alineamiento
        my_output1.write(listado1) #escribimos el archivo
        my_output1.close()

    print("\n---El alineamiento de las secuencias para la realización del arbol filogenético ha sido realizado con éxito---\n")

#función para realizar el árbol filogenético del alineamiento de las secuencias
def Hacer_arbol(lista_querys,i):
	
    for j in lista_querys: #se recorren las distintas querys que tendrán su archivo con las secuencias alineadas
        #mediante Popen se realiza el proceso de realización del árbol, se redirige la salida directamente al archivo .tree que contendrá el árbol
        proceso2 = Popen(['muscle','-maketree','-in',j+"_alineado.fasta",'-out', j+".tree", '-cluster', 'neighborjoining'], stderr=PIPE)
    
    
    